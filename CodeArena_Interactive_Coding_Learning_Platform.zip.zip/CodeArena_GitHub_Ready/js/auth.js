"use strict";

const USERS_KEY = "ca_users";
const CURRENT_USER_KEY = "ca_currentUser";
const $ = (id) => document.getElementById(id);

function getUsers() {
    try {
        const value = JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
        return Array.isArray(value) ? value : [];
    } catch { return []; }
}

function showAuthMessage(message, type = "error") {
    const box = $("authMessage");
    if (!box) return;
    box.textContent = message;
    box.className = `auth-message show ${type}`;
}

function updateAuthYear() {
    const year = $("authYear");
    if (year) year.textContent = new Date().getFullYear();
}

async function hashPassword(password, saltHex) {
    if (!window.crypto?.subtle) throw new Error("Secure password hashing is not available. Open this project through localhost.");
    const salt = saltHex ? Uint8Array.from(saltHex.match(/.{1,2}/g), b => parseInt(b, 16)) : crypto.getRandomValues(new Uint8Array(16));
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: 120000, hash: "SHA-256" }, key, 256);
    return { salt: Array.from(salt, b => b.toString(16).padStart(2, "0")).join(""), hash: Array.from(new Uint8Array(bits), b => b.toString(16).padStart(2, "0")).join("") };
}

function safeUser(user) {
    return { id: user.id, fullName: user.fullName, username: user.username, email: user.email };
}

document.addEventListener("DOMContentLoaded", () => {
    updateAuthYear();
    document.querySelectorAll(".password-toggle").forEach(button => {
        button.addEventListener("click", () => {
            const field = $(button.dataset.target);
            if (!field) return;
            field.type = field.type === "password" ? "text" : "password";
            const icon = button.querySelector("i");
            if (icon) icon.className = field.type === "password" ? "bi bi-eye" : "bi bi-eye-slash";
            button.setAttribute("aria-label", field.type === "password" ? "Show password" : "Hide password");
        });
    });

    const signupForm = $("signupForm");
    if (signupForm) signupForm.addEventListener("submit", async event => {
        event.preventDefault();
        const fullName = $("fullName").value.trim().replace(/\s+/g, " ");
        const username = $("username").value.trim();
        const email = $("email").value.trim().toLowerCase();
        const password = $("password").value;
        const confirmPassword = $("confirmPassword").value;
        if (fullName.length < 2) return showAuthMessage("Please enter your full name.");
        if (username.length < 3 || !/^[a-zA-Z0-9_]+$/.test(username)) return showAuthMessage("Username must be 3+ characters and use only letters, numbers or underscores.");
        if (password.length < 8) return showAuthMessage("Use a password with at least 8 characters.");
        if (password !== confirmPassword) return showAuthMessage("Passwords do not match.");
        const users = getUsers();
        if (users.some(user => user.email === email)) return showAuthMessage("This email is already registered. Please log in.");
        if (users.some(user => user.username.toLowerCase() === username.toLowerCase())) return showAuthMessage("This username is already taken.");
        const submit = signupForm.querySelector('[type="submit"]');
        if (submit) { submit.disabled = true; submit.textContent = "Creating account..."; }
        try {
            const credentials = await hashPassword(password);
            users.push({ id: Date.now(), fullName, username, email, passwordHash: credentials.hash, salt: credentials.salt, createdAt: new Date().toISOString() });
            localStorage.setItem(USERS_KEY, JSON.stringify(users));
            showAuthMessage("Account created! You can now log in.", "success");
            signupForm.reset();
            setTimeout(() => { window.location.href = "login.html"; }, 900);
        } catch (error) {
            showAuthMessage(error.message || "Could not save your account in this browser.");
        } finally {
            if (submit) { submit.disabled = false; submit.textContent = "Create Account"; }
        }
    });

    const loginForm = $("loginForm");
    if (loginForm) loginForm.addEventListener("submit", async event => {
        event.preventDefault();
        const email = $("email").value.trim().toLowerCase();
        const password = $("password").value;
        const users = getUsers();
        const matchedUser = users.find(user => user.email === email);
        if (!matchedUser) return showAuthMessage("No account found with this email. Please sign up first.");
        try {
            let valid = false;
            if (matchedUser.passwordHash && matchedUser.salt) {
                const result = await hashPassword(password, matchedUser.salt);
                valid = result.hash === matchedUser.passwordHash;
            } else {
                // Upgrade accounts created by the earlier demo version.
                valid = matchedUser.password === password;
                if (valid) {
                    const result = await hashPassword(password);
                    matchedUser.passwordHash = result.hash;
                    matchedUser.salt = result.salt;
                    delete matchedUser.password;
                    localStorage.setItem(USERS_KEY, JSON.stringify(users));
                }
            }
            if (!valid) return showAuthMessage("Incorrect password. Please try again.");
            localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(safeUser(matchedUser)));
            showAuthMessage("Login successful! Opening your profile...", "success");
            setTimeout(() => { window.location.href = "profile.html"; }, 650);
        } catch (error) { showAuthMessage(error.message || "Unable to log in. Please try again."); }
    });
});
