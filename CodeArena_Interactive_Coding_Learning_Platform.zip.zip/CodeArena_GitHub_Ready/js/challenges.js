
const challenges = [
    {id: 1, title: "Hello World", level: "Easy", points: 10, desc: "Write your first JavaScript program and print Hello World."},
    {id: 2, title: "Sum of Two Numbers", level: "Easy", points: 15, desc: "Create a program that adds two given numbers."},
    {id: 3, title: "Even or Odd", level: "Easy", points: 15, desc: "Check whether a given number is even or odd."},
    {id: 4, title: "Reverse a String", level: "Medium", points: 25, desc: "Write a program to reverse a given string."},
    {id: 5, title: "Find Maximum Number", level: "Medium", points: 25, desc: "Find the largest number from an array."},
    {id: 6, title: "Palindrome Checker", level: "Medium", points: 30, desc: "Check if a word reads the same backwards."},
    {id: 7, title: "Fibonacci Sequence", level: "Medium", points: 35, desc: "Generate a Fibonacci sequence up to a given number."},
    {id: 8, title: "Two Sum Problem", level: "Hard", points: 50, desc: "Find two array elements whose sum equals a target."},
    {id: 9, title: "Array Sorting", level: "Hard", points: 50, desc: "Sort an array of numbers without using sort()."},
    {id: 10, title: "Valid Parentheses", level: "Hard", points: 60, desc: "Check whether brackets are correctly balanced."}
];

let activeFilter = "All";

function getSolved() {
    try { return JSON.parse(localStorage.getItem("ca_solved_" + (JSON.parse(localStorage.getItem("ca_currentUser") || "null")?.id || "guest")) || "[]"); } catch { return []; }
}

function renderChallenges() {
    const list = document.getElementById("challengeList");
    const search = document.getElementById("searchInput").value.toLowerCase();
    const solved = getSolved();

    const filtered = challenges.filter(challenge => {
        const matchesLevel = activeFilter === "All" || challenge.level === activeFilter;
        const matchesSearch = `${challenge.title} ${challenge.desc} ${challenge.level}`.toLowerCase().includes(search);
        return matchesLevel && matchesSearch;
    });

    list.innerHTML = filtered.map(challenge => {
        const isSolved = solved.includes(challenge.id);

        return `
            <div class="col-md-6 col-lg-4">
                <div class="challenge-card">
                    <span class="difficulty ${challenge.level}">
                        ${challenge.level}
                    </span>

                    <h4>${challenge.title}</h4>

                    <p>${challenge.desc}</p>

                    <div class="challenge-bottom">
                        <span><i class="bi bi-star-fill"></i> ${challenge.points} Points</span>

                        <button class="solve-btn ${isSolved ? "solved" : ""}"
                            onclick="toggleSolved(${challenge.id})">
                            ${isSolved ? "✓ Solved" : "Mark Solved"}
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join("");

    document.getElementById("emptyMessage").hidden = filtered.length !== 0;
    document.getElementById("solvedCount").textContent = solved.length;
}

function toggleSolved(id) {
    let solved = getSolved();

    if (solved.includes(id)) {
        solved = solved.filter(item => item !== id);
    } else {
        solved.push(id);
    }

    const userId = JSON.parse(localStorage.getItem("ca_currentUser") || "null")?.id || "guest";
    localStorage.setItem("ca_solved_" + userId, JSON.stringify(solved));
    renderChallenges();
}

document.querySelectorAll(".filter-btn").forEach(button => {
    button.addEventListener("click", function () {
        document.querySelector(".filter-btn.active")?.classList.remove("active");
        this.classList.add("active");

        activeFilter = this.dataset.filter;
        renderChallenges();
    });
});

document.getElementById("searchInput").addEventListener("input", renderChallenges);

renderChallenges();
