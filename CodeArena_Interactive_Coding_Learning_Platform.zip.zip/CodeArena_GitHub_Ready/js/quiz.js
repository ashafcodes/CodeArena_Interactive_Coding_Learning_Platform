
const questions = [
    {
        question: "Which keyword is used to declare a variable in JavaScript?",
        options: ["style", "let", "print", "define"],
        answer: 1
    },
    {
        question: "Which symbol is used for single-line comments?",
        options: ["//", "/*", "<!--", "##"],
        answer: 0
    },
    {
        question: "Which method displays a message in the browser console?",
        options: ["show()", "display()", "console.log()", "write()"],
        answer: 2
    },
    {
        question: "Which data type represents true or false?",
        options: ["String", "Boolean", "Number", "Array"],
        answer: 1
    },
    {
        question: "Which operator checks both value and data type?",
        options: ["=", "==", "===", "!="],
        answer: 2
    },
    {
        question: "Which method adds an item to the end of an array?",
        options: ["push()", "pop()", "shift()", "join()"],
        answer: 0
    },
    {
        question: "Which keyword is used to create a function?",
        options: ["function", "method", "create", "func"],
        answer: 0
    },
    {
        question: "What does NaN mean in JavaScript?",
        options: ["New Array Number", "Not a Number", "No Active Name", "Number and Null"],
        answer: 1
    },
    {
        question: "Which loop runs while a condition is true?",
        options: ["if loop", "switch", "while loop", "break loop"],
        answer: 2
    },
    {
        question: "Which method converts JSON text into a JavaScript object?",
        options: ["JSON.stringify()", "JSON.parse()", "JSON.convert()", "JSON.object()"],
        answer: 1
    }
];

let currentQuestion = 0;
let score = 0;
let selectedAnswer = null;
let answered = false;

const questionText = document.getElementById("questionText");
const optionsList = document.getElementById("optionsList");
const questionNumber = document.getElementById("questionNumber");
const progressBar = document.getElementById("progressBar");
const nextBtn = document.getElementById("nextBtn");
const questionHint = document.getElementById("questionHint");
const quizCard = document.getElementById("quizCard");
const resultCard = document.getElementById("resultCard");

function loadQuestion() {
    const question = questions[currentQuestion];

    selectedAnswer = null;
    answered = false;

    questionNumber.textContent =
        `QUESTION ${String(currentQuestion + 1).padStart(2, "0")} / ${questions.length}`;

    questionText.textContent = question.question;

    progressBar.style.width =
        `${((currentQuestion + 1) / questions.length) * 100}%`;

    optionsList.innerHTML = "";
    questionHint.textContent = "Select one correct answer";

    nextBtn.disabled = true;
    nextBtn.innerHTML = currentQuestion === questions.length - 1
        ? 'Finish Quiz <i class="bi bi-check-circle"></i>'
        : 'Next Question <i class="bi bi-arrow-right"></i>';

    question.options.forEach((option, index) => {
        const button = document.createElement("button");

        button.className = "option-btn";
        button.textContent =
            `${String.fromCharCode(65 + index)}.  ${option}`;

        button.addEventListener("click", () => selectAnswer(index));

        optionsList.appendChild(button);
    });
}

function selectAnswer(index) {
    if (answered) return;

    selectedAnswer = index;
    answered = true;

    const question = questions[currentQuestion];
    const buttons = optionsList.querySelectorAll(".option-btn");

    buttons.forEach((button, buttonIndex) => {
        button.disabled = true;

        if (buttonIndex === question.answer) {
            button.classList.add("correct");
        }

        if (buttonIndex === selectedAnswer && selectedAnswer !== question.answer) {
            button.classList.add("wrong");
        }
    });

    if (selectedAnswer === question.answer) {
        score += 10;
        questionHint.textContent = "Correct answer! +10 points";
    } else {
        questionHint.textContent = "Not quite! The correct answer is highlighted.";
    }

    nextBtn.disabled = false;
}

nextBtn.addEventListener("click", () => {
    if (!answered) return;

    currentQuestion++;

    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        showResult();
    }
});

function showResult() {
    quizCard.hidden = true;
    resultCard.hidden = false;

    document.getElementById("finalScore").textContent =
        `${score}/${questions.length * 10}`;

    const correctAnswers = score / 10;

    document.getElementById("resultTitle").textContent =
        score >= 80 ? "Excellent Work!" :
        score >= 50 ? "Good Job!" : "Keep Practicing!";

    document.getElementById("resultMessage").textContent =
        score >= 80 ? "You're doing amazing. Keep coding!" :
        score >= 50 ? "Nice effort! A little more practice will help." :
        "Don't give up. Practice makes you better!";

    document.getElementById("resultDetails").textContent =
        `You answered ${correctAnswers} out of ${questions.length} questions correctly.`;

    // Save latest quiz score in the browser
    const userId = JSON.parse(localStorage.getItem("ca_currentUser") || "null")?.id || "guest";
    localStorage.setItem("ca_quizScore_" + userId, score);
}

document.getElementById("restartBtn").addEventListener("click", () => {
    currentQuestion = 0;
    score = 0;
    selectedAnswer = null;
    answered = false;

    resultCard.hidden = true;
    quizCard.hidden = false;

    loadQuestion();
});

loadQuestion();
