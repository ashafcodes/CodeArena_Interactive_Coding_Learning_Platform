const activeUser = JSON.parse(localStorage.getItem("ca_currentUser") || "null");
const solvedChallenges = JSON.parse(localStorage.getItem("ca_solved_" + (activeUser?.id || "guest")) || "[]");
const quizScore = Number(localStorage.getItem("ca_quizScore_" + (activeUser?.id || "guest")) || 0);

// The first five entries are sample leaderboard participants for this frontend demo.
const players = [
    { name: "Sarah Khan", points: 950, solved: 45, initials: "SK" },
    { name: "Ali Malik", points: 820, solved: 39, initials: "AM" },
    { name: "Hassan Raza", points: 760, solved: 35, initials: "HR" },
    { name: "Ayesha Noor", points: 680, solved: 30, initials: "AN" },
    { name: "Usman Ahmed", points: 590, solved: 25, initials: "UA" },
    { name: activeUser?.fullName || "Your Account", points: 0, solved: 0,
      initials: (activeUser?.fullName || "YA").split(/\s+/).map(part => part[0]).join("").slice(0, 2).toUpperCase(), isUser: true }
];

// Add user's points
const user = players.find(player => player.isUser);

user.points = solvedChallenges.reduce((total, id) => total + ({1:10,2:15,3:15,4:25,5:25,6:30,7:35,8:50,9:50,10:60}[id] || 0), 0) + quizScore;
user.solved = solvedChallenges.length;

players.sort((a, b) => b.points - a.points);

const leaderboardBody = document.getElementById("leaderboardBody");

function renderLeaderboard() {
    leaderboardBody.innerHTML = "";

    players.forEach((player, index) => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td class="rank-number">#${index + 1}</td>
            <td>
                <span class="player-avatar">${player.initials}</span>
                <span class="player-name">${player.name}</span>
                ${player.isUser ? '<span class="you-badge">YOU</span>' : ""}
            </td>
            <td>${player.solved}</td>
            <td class="points-value">${player.points} pts</td>
        `;

        leaderboardBody.appendChild(row);
    });

    document.getElementById("totalPlayers").textContent = players.length;
    document.getElementById("topScore").textContent = players[0].points;

    const yourRank = players.findIndex(player => player.isUser) + 1;

    document.getElementById("yourRank").textContent = `#${yourRank}`;

    document.getElementById("yourPositionText").textContent =
        `You are ranked #${yourRank} with ${user.points} points. Keep practicing!`;
}

renderLeaderboard();
