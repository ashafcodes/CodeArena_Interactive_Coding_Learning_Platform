
const currentUser = JSON.parse(
    localStorage.getItem("ca_currentUser") || "null"
);

// User must be logged in to view this page
if (!currentUser) {
    window.location.href = "login.html";
} else {
    const solvedChallenges = JSON.parse(
        localStorage.getItem("ca_solved_" + currentUser.id) || "[]"
    );

    const quizScore = Number(
        localStorage.getItem("ca_quizScore_" + currentUser.id) || 0
    );

    const solvedCount = solvedChallenges.length;
    const xp = (solvedCount * 10) + quizScore;
    const level = Math.floor(xp / 100) + 1;

    function setText(id, value) {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    }

    // Profile identity
    setText("profileName", currentUser.fullName);
    setText("profileUsername", "@" + currentUser.username);
    setText("profileAvatar", currentUser.fullName
        .split(" ")
        .map(word => word[0])
        .join("")
        .slice(0, 2)
        .toUpperCase()
    );

    // Personal information
    setText("infoName", currentUser.fullName);
    setText("infoUsername", "@" + currentUser.username);
    setText("infoEmail", currentUser.email);

    const users = JSON.parse(localStorage.getItem("ca_users") || "[]");
    const savedUser = users.find(user => user.id === currentUser.id);

    if (savedUser && savedUser.createdAt) {
        setText(
            "infoDate",
            new Date(savedUser.createdAt).toLocaleDateString()
        );
    } else {
        setText("infoDate", "Recently");
    }

    // Statistics
    setText("profileXP", xp + " XP");
    setText("profileSolved", solvedCount);
    setText("profileQuiz", quizScore + "/100");
    setText("profileLevel", "Level " + level);

    // Progress bars
    const challengePercent = Math.min((solvedCount / 10) * 100, 100);

    setText("challengePercent", Math.round(challengePercent) + "%");
    const challengeProgress = document.getElementById("challengeProgress");
    if (challengeProgress) challengeProgress.style.width = challengePercent + "%";

    setText("quizPercent", quizScore + "%");
    const quizProgress = document.getElementById("quizProgress");
    if (quizProgress) quizProgress.style.width = quizScore + "%";

    setText(
        "levelMessage",
        `You are at Level ${level}. Earn ${100 - (xp % 100)} more XP to reach the next level!`
    );

    // Achievements
    if (solvedCount >= 1) {
        document.getElementById("firstChallenge")?.classList.add("unlocked");
    }

    if (quizScore >= 80) {
        document.getElementById("quizMaster")?.classList.add("unlocked");
    }

    if (solvedCount >= 5) {
        document.getElementById("problemSolver")?.classList.add("unlocked");
    }
}

// Logout
document.getElementById("logoutBtn")?.addEventListener("click", function() {
    localStorage.removeItem("ca_currentUser");
    window.location.href = "login.html";
});

// Footer year
const currentYear = document.getElementById("currentYear");
if (currentYear) currentYear.textContent = new Date().getFullYear();
