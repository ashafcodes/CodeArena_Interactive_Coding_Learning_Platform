
const codeEditor = document.getElementById("codeEditor");
const output = document.getElementById("output");
const runBtn = document.getElementById("runBtn");
const resetBtn = document.getElementById("resetBtn");
const clearOutput = document.getElementById("clearOutput");
const lineNumbers = document.getElementById("lineNumbers");

const starterCode = `// Welcome to CodeArena Playground!

let name = "CodeArena";
let language = "JavaScript";

console.log("Hello, " + name + "!");
console.log("Welcome to " + language);

let a = 10;
let b = 20;

console.log("Sum:", a + b);`;

codeEditor.value = starterCode;

function updateLines() {
    const totalLines = codeEditor.value.split("\n").length;

    lineNumbers.textContent = Array.from(
        { length: totalLines },
        (_, index) => index + 1
    ).join("\n");
}

function showOutput(message, type = "normal") {
    const line = document.createElement("div");
    line.className = "output-line";

    if (type === "error") {
        line.classList.add("output-error");
    }

    line.textContent = message;
    output.appendChild(line);
}

function formatValue(value) {
    if (typeof value === "string") return value;

    if (typeof value === "undefined") return "undefined";

    try {
        return JSON.stringify(value) ?? String(value);
    } catch {
        return String(value);
    }
}

runBtn.addEventListener("click", function () {
    output.innerHTML = "";

    const userCode = codeEditor.value;

    const sandbox = document.createElement("iframe");

    sandbox.setAttribute("sandbox", "allow-scripts");
    sandbox.style.display = "none";

    const safeCode = JSON.stringify(userCode);

    sandbox.srcdoc = `
        <!DOCTYPE html>
        <html>
        <body>
        <script>
            const send = (type, values) => {
                parent.postMessage({
                    source: "codearena-playground",
                    type,
                    values
                }, "*");
            };

            console.log = (...args) => {
                send("log", args.map(value => {
                    try {
                        return JSON.stringify(value) ?? String(value);
                    } catch {
                        return String(value);
                    }
                }));
            };

            console.error = (...args) => {
                send("error", args.map(String));
            };

            try {
                const code = ${safeCode};
                new Function(code)();
            } catch (error) {
                send("error", [error.message]);
            }
        <\/script>
        </body>
        </html>
    `;

    const receiveOutput = function (event) {
        if (event.source !== sandbox.contentWindow) return;
        if (event.data?.source !== "codearena-playground") return;

        const values = event.data.values || [];
        const message = values.join(" ");

        if (event.data.type === "error") {
            showOutput("Error: " + message, "error");
        } else {
            showOutput(message);
        }
    };

    window.addEventListener("message", receiveOutput);

    sandbox.onload = function () {
        setTimeout(() => {
            window.removeEventListener("message", receiveOutput);
            sandbox.remove();
        }, 1000);
    };

    document.body.appendChild(sandbox);
});

resetBtn.addEventListener("click", function () {
    codeEditor.value = starterCode;
    output.innerHTML = "";
    updateLines();
});

clearOutput.addEventListener("click", function () {
    output.innerHTML = "";
});

codeEditor.addEventListener("input", updateLines);

updateLines();
