# CodeArena — Learn, Practice & Compete

CodeArena is a responsive, front-end coding practice website built with **HTML, CSS, JavaScript and Bootstrap 5**. It brings together coding challenges, a JavaScript playground, quick quizzes, a leaderboard and a personal progress dashboard in one clean dark interface.

## Features

- **Home page:** project introduction, feature highlights and quick navigation.
- **Coding challenges:** search challenges, filter by difficulty and track completed problems.
- **JavaScript playground:** write and run JavaScript in an isolated browser iframe, view console output and reset the starter code.
- **Quizzes:** ten JavaScript questions with instant answer feedback, score and restart option.
- **Leaderboard:** sample participants plus the current local user's score and rank.
- **Account demo:** create an account, log in, show/hide passwords and log out.
- **Profile dashboard:** account details, XP, level, progress bars and achievements.
- **Responsive layout:** designed for desktop, tablet and mobile screens.

## Run locally

1. Download or clone this repository.
2. Open the project folder in Visual Studio Code.
3. Install the **Live Server** extension if you do not already have it.
4. Right-click `index.html` and choose **Open with Live Server**.
5. Use **Create Account** to make a demo account, then log in.

You can also deploy the folder to GitHub Pages. The project uses relative file paths, so it can run as a static site.

## Project structure

```text
CodeArena/
├── index.html
├── challenges.html
├── playground.html
├── quiz.html
├── leaderboard.html
├── login.html
├── signup.html
├── profile.html
├── css/
│   ├── style.css
│   ├── responsive.css
│   ├── auth.css
│   ├── challenges.css
│   ├── leaderboard.css
│   ├── playground.css
│   ├── profile.css
│   └── quiz.css
├── js/
│   ├── main.js
│   ├── auth.js
│   ├── challenges.js
│   ├── playground.js
│   ├── quiz.js
│   ├── leaderboard.js
│   └── profile.js
└── README.md
```

## Technology

- HTML5
- CSS3 (custom responsive styling)
- JavaScript (ES6+)
- Bootstrap 5.3.3
- Bootstrap Icons
- Browser Local Storage
- Web Crypto API (PBKDF2 password hashing for the local demo)

## Important demo limitations

This is a **front-end learning/demo project**, not a production authentication or competitive coding platform. Accounts and progress are stored in the current browser's Local Storage; they are not synchronized between devices or users. Clearing browser data removes locally saved accounts and progress. Passwords are hashed in the browser for this demo, but a real public service must use a trusted server, database, HTTPS, server-side authentication, rate limiting and proper authorization. The leaderboard's other participants are sample data. Challenges are manually marked as solved and are not automatically judged against test cases. The playground executes JavaScript only and should be treated as a learning sandbox, not a secure environment for untrusted code.

## Customization

- Update colors and shared styles in `css/style.css`.
- Update challenge content in `js/challenges.js`.
- Update quiz questions in `js/quiz.js`.
- Update the sample leaderboard entries in `js/leaderboard.js`.

## License

This project is available under the MIT License. See [LICENSE](LICENSE).
